# To create a project we are using vite 
# Run command `npm create vite@latest`

# For API we are using TMDB (The movie database)