import React, { useRef } from "react";
import {
  BsFillArrowLeftCircleFill,
  BsFillArrowRightCircleFill,
} from "react-icons/bs";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import dayjs from "dayjs";

import ContentWrapper from "../contentWrapper/ContentWrapper";
import Img from "../lazyLoadImage/Img";
import PosterFallback from "../../assets/no-poster.png";
import CircleRating from "../circleRating/CircleRating";
import "./style.scss";
const Carousel = ({ data, loading }) => {
  // console.log("**********", data);
  // console.log("***************", loading);

  const carouselContainer = useRef();
  const { url } = useSelector((state) => state.home);

  // console.log("***************", url);

  const skItem = () => {
    return (
      <div className="skeletonItem">
        <div className="posterBlock skeleton">
          <div className="textBlock">
            <div className="title skeleton"></div>
            <div className="date skeleton"></div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="carousel">
      <ContentWrapper>
        <BsFillArrowLeftCircleFill className="carouselLeftNav arrow" />
        <BsFillArrowRightCircleFill
          className="carouselRightNav arrow"
          //  onClick={}
        />

        {!loading ? (
          <div className="carouselItems">
            {data?.map((value) => {
              const posterUrl = value?.poster_path
                ? url?.poster + value?.poster_path
                : PosterFallback;
              return (
                <div key={value.id} className="carouselItem">
                  <div className="posterBlock">
                    <Img src={posterUrl} />
                    <CircleRating rating={value?.vote_average.toFixed(1)}/>
                  </div>

                  <div className="textBlock">
                    <span className="title">{value?.title || value?.name}</span>
                    <span className="date">
                      {dayjs(value?.release_date).format("MMM D, YYYY")}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="loadingSkeleton">
            {skItem()}
            {skItem()}
            {skItem()}
            {skItem()}
            {skItem()}
          </div>
        )}
      </ContentWrapper>
    </div>
  );
};

export default Carousel;
// 3:47
