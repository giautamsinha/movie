import { useEffect } from "react";
import { fetchDataFromApi } from "./utils/api";
import { useDispatch, useSelector } from "react-redux";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Header from "./components/header/Header";
import Footer from "./components/footer/Footer";
import Home from "./pages/home/Home";
import Explore from "./pages/explore/Explore";
import Details from "./pages/details/Details";
import Error from "./pages/404/Error";
import SearchResult from "./pages/searchResult/SearchResult";
import useFatch from "./hooks/useFatch";
import { getApiConfigration } from "./store/homeSlice";

function App() {
  const { url } = useSelector((state) => state.home);
  const dispatch = useDispatch();
  // const {data,loading} = useFatch("/movie/popular")
  // dispatch(getApiConfigration(data));

  useEffect(() => {
    const getData = async () => {
      const { data } = await dispatch(fetchDataFromApi("/configuration"));
      console.log("working", data);
      const url = {
        backdrop: data?.images?.secure_base_url + "original",
        poster: data?.images?.secure_base_url + "original",
        profile: data?.images?.secure_base_url + "original",
      };
      dispatch(getApiConfigration(url));
    };
    getData();
    genersCall();
  }, []);

  const genersCall = async () => {
    let endPoints = ["tv", "movie"];
    let promises = [];
    let allGeners = {};
    
    endPoints.forEach(async (url , index) => {
      const {data} = await dispatch(fetchDataFromApi(`/genre/${url}/list`))
    // console.log("index",index);
      return promises.push(data);
    //   data.map((geners)=>{
    // console.log("geners",geners);

    //   })
    });
    console.log("geners",promises.geners);
    // console.log("geners",promises);
    
    for(let k of promises){
      console.log("123",k)
    }
    

  };

  return (
    <>
      <BrowserRouter>
        <Header />

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/:medieaType/:id" element={<Details />} />
          <Route path="/search/:query" element={<SearchResult />} />
          <Route path="/:explore/:medieaType" element={<Explore />} />
          <Route path="*" element={<Error />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </>
  );
}

export default App;
