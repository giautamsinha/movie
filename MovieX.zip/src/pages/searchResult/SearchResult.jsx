import "./style.scss"

const SearchResult = () => {
  return (
    <div>SearchResult</div>
  )
}

export default SearchResult