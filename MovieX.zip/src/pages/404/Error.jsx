import "./style.scss"
const error = () => {
  return (
    <div>error</div>
  )
}

export default error